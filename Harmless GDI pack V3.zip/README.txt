Since most people didn't like the console window showing I've decieded to hide the window and put new programs on there remade from me prgbquad-370

HARMLESS MALWARE PACK V3